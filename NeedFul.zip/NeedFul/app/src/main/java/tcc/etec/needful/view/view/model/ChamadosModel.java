package tcc.etec.needful.view.view.model;

import com.google.android.gms.common.api.Api;

import java.sql.Date;
import java.sql.Time;

public class ChamadosModel {

    private int id;
    private Date data;
    private Time horas;
    private Date agendamento;
    private String descricao;
    private int tipoChamado;
    private int idTecnico;
    private int idStatusChamado;
    private ClienteModel clientVO;

    public int getTipoChamado() {
        return tipoChamado;
    }

    public void setTipoChamado(int tipoChamado) {
        this.tipoChamado = tipoChamado;
    }

    public int getIdTecnico() {
        return idTecnico;
    }

    public void setIdTecnico(int idTecnico) {
        this.idTecnico = idTecnico;
    }

    public int getIdStatusChamado() {
        return idStatusChamado;
    }

    public void setIdStatusChamado(int idStatusChamado) {
        this.idStatusChamado = idStatusChamado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Time getHoras() {
        return horas;
    }

    public void setHoras(Time horas) {
        this.horas = horas;
    }

    public Date getAgendamento() {
        return agendamento;
    }

    public void setAgendamento(Date agendamento) {
        this.agendamento = agendamento;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public ClienteModel getClientVO() {
        return clientVO;
    }

    public void setClientVO(ClienteModel clientVO) {
        this.clientVO = clientVO;
    }

}
