package tcc.etec.needful.view.view.util;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import tcc.etec.needful.view.view.controller.ChamadosController;
import tcc.etec.needful.view.view.datamodel.ChamadosDataModel;
import tcc.etec.needful.view.view.datasource.DataSource;
import tcc.etec.needful.view.view.model.ChamadosModel;



public class Sincronizar  extends AsyncTask<String, String, String> {

    ChamadosController controller;
    ProgressDialog progressDialog;
    Context context;
    HttpURLConnection connection;
    URL url = null;
    Uri.Builder builder;


    public Sincronizar() {

        this.builder = new Uri.Builder();
        builder.appendQueryParameter("app", "NeedFul");

    }

    @Override
    protected String doInBackground(String... strings) {

        //montar a URL com o endereço do script PHP

        try {

            url = new URL(UtilChamados.URL_WEB_SERVICE + "APISincronizarSistema.php");

        } catch (MalformedURLException e) {

            Log.e("Web Service ", "MalformedURLException - " + e.getMessage());

        } catch (Exception erro) {

            Log.e("Web Service ", "Exception - " + erro.getMessage());

        }

        try {

            connection = (HttpURLConnection) url.openConnection();
            connection.setReadTimeout(UtilChamados.READ_TIMEOUT);
            connection.setConnectTimeout(UtilChamados.CONNECTION_TIMEOUT);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("charset", "utf-8");

            connection.setDoInput(true);
            connection.setDoOutput(true);

            connection.connect();

            String query = builder.build().getEncodedQuery();

            OutputStream os = connection.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            writer.write(query);
            writer.flush();
            writer.close();
            os.close();
            connection.connect();


        } catch (IOException e) {

            Log.e("Web Service ", "IOException - " + e.getMessage());
        }

        try{

            int response_code = connection.getResponseCode();

            if(response_code == HttpURLConnection.HTTP_OK){

                InputStream input = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                StringBuilder resultado = new StringBuilder();


                String linha;

                while((linha = reader.readLine()) != null){
                    resultado.append(linha);
                }
                return resultado.toString();
            }else{
                return "Erro de conexão";
            }

        }catch (IOException e){

            Log.e("WebService","IOException - "+e.getMessage());

            return e.toString();

        }finally{

            connection.disconnect();
        }

    }

    @Override
    protected void onPostExecute(String result) {

        try{

            JSONArray jArray = new JSONArray(result);

            if(jArray.length() != 0){

                controller.deletarTabela(ChamadosDataModel.getTABELA());
                controller.criarTabela(ChamadosDataModel.criarTabela());

                for (int i = 0; i < jArray.length(); i++){

                    JSONObject jsonObject = jArray.getJSONObject(i);

                    ChamadosModel obj = new ChamadosModel();

                    /*obj.setId_chamado(jsonObject.getInt(ChamadosDataModel.getId()));
                    obj.setId_cliente(jsonObject.getInt(ChamadosDataModel.getIdCliente()));
                    obj.setHoraChamado(jsonObject.getString(ChamadosDataModel.getHora()));
                    obj.setDataChamado(jsonObject.getString(ChamadosDataModel.getData()));
                    obj.setDataMarcada(jsonObject.getString(ChamadosDataModel.getAgendamento_chamado()));
                    obj.setRoteador(jsonObject.getString(ChamadosDataModel.getRoteador()));
                    obj.setObservacao(jsonObject.getString(ChamadosDataModel.getObs()));
                    obj.setId_tecnico(jsonObject.getInt(ChamadosDataModel.getId_tecnico()));
                    obj.setId_tipo_chamado(jsonObject.getInt(ChamadosDataModel.getTipoChamado()));
                    obj.setId_status_chamados(jsonObject.getInt(ChamadosDataModel.getId_status_chamado()));

                    controller.salvar(obj);*/
                }


            }else{

                //Toast.makeText(context , "Nenhum registro encontrado", Toast.LENGTH_LONG).show();
            }

        }catch (JSONException e){

            Log.e("WebService", "erro JSONException - " + e.getMessage());

        }finally {

            if(progressDialog != null && progressDialog.isShowing()){
                progressDialog.dismiss();


            }

        }


    }
}
