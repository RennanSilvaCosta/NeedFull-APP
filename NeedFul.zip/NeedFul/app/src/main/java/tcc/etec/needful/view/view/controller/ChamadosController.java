package tcc.etec.needful.view.view.controller;

import android.content.ContentValues;
import android.content.Context;

import java.util.ArrayList;

import tcc.etec.needful.view.view.datamodel.ChamadosDataModel;
import tcc.etec.needful.view.view.datamodel.ClienteDataModel;
import tcc.etec.needful.view.view.datamodel.EnderecoDataModel;
import tcc.etec.needful.view.view.datamodel.UsuarioDataModel;
import tcc.etec.needful.view.view.datasource.DataSource;
import tcc.etec.needful.view.view.model.ChamadosModel;
import tcc.etec.needful.view.view.model.ClienteModel;
import tcc.etec.needful.view.view.model.EnderecoModel;
import tcc.etec.needful.view.view.model.UsuarioModel;

public class ChamadosController extends DataSource {

    public ChamadosController(Context context) {
        super(context);
    }

    ContentValues dados;
    ContentValues dadosCliente;
    ContentValues dadosEndereco;

    public boolean salvarUser(UsuarioModel user) {

        boolean retorno;

        dados = new ContentValues();

        dados.put(UsuarioDataModel.getId(), user.getIdUsuario());
        dados.put(UsuarioDataModel.getNome(), user.getNomeUsuario());
        dados.put(UsuarioDataModel.getEmail(), user.getEmailUsuario());
        dados.put(UsuarioDataModel.getCpf(), user.getCpfUsuario());
        dados.put(UsuarioDataModel.getLogin(), user.getLoginUsuario());
        dados.put(UsuarioDataModel.getSenha(), user.getSenhaUsuario());
        dados.put(UsuarioDataModel.getTipo_usuario(), user.getIdTipoUsuario());

        retorno = insert(UsuarioDataModel.getTABELA(), dados);

        return retorno;
    }

    public ArrayList<ChamadosModel> todosChamados(int idTecnico){

        return listarChamados(idTecnico);

    }

    public ArrayList<ChamadosModel> todosAgendados(int idTecnico){

        return listarAgendados(idTecnico);

    }

    public ArrayList<ChamadosModel> listarFinalizados(int idTecnico){

        return listarChamadosFinalizados(idTecnico);

    }

    public ChamadosModel buscarPorid(int id){

        return buscarChamadoPorId(id);

    }

    public UsuarioModel buscarUser(String login){

        return buscarUsuario(login);
    }

    public boolean alterar(ChamadosModel chamados) {

        boolean salvou = true;

        dados = new ContentValues();

        dados.put(ChamadosDataModel.getId(), chamados.getId());
        dados.put(ChamadosDataModel.getDataChamado(), String.valueOf(chamados.getData()));
        dados.put(ChamadosDataModel.getHoraChamado(), String.valueOf(chamados.getHoras()));
        dados.put(ChamadosDataModel.getAgendamentoChamado(), String.valueOf(chamados.getAgendamento()));
        dados.put(ChamadosDataModel.getObservacaoChamado(), chamados.getDescricao());
        dados.put(ChamadosDataModel.getIdTecnico(), chamados.getIdTecnico());
        dados.put(ChamadosDataModel.getIdTipoChamado(), chamados.getTipoChamado());
        dados.put(ChamadosDataModel.getIdStatusChamado(), chamados.getIdStatusChamado());

       salvou = Update(ChamadosDataModel.getTABELA(), dados, "id_chamado=?", new String[] {String.valueOf(chamados.getId())});

        return salvou;
    }

    public boolean salvar(ChamadosModel chamados, ClienteModel cliente, EnderecoModel endereco) {

        boolean retornoChamado = true;
        boolean retornoCliente = true;
        boolean retornoEndereco = true;

        dados = new ContentValues();
        dadosCliente = new ContentValues();
        dadosEndereco = new ContentValues();

        //DADOS DO CHAMADO
        dados.put(ChamadosDataModel.getId(), chamados.getId());
        dados.put(ChamadosDataModel.getIdCliente(), cliente.getId());
        dados.put(ChamadosDataModel.getDataChamado(), String.valueOf(chamados.getData()));
        dados.put(ChamadosDataModel.getHoraChamado(), String.valueOf(chamados.getHoras()));
        dados.put(ChamadosDataModel.getAgendamentoChamado(), String.valueOf(chamados.getAgendamento()));
        dados.put(ChamadosDataModel.getObservacaoChamado(), chamados.getDescricao());
        dados.put(ChamadosDataModel.getIdTecnico(), chamados.getIdTecnico());
        dados.put(ChamadosDataModel.getIdTipoChamado(), chamados.getTipoChamado());
        dados.put(ChamadosDataModel.getIdStatusChamado(), chamados.getIdStatusChamado());

        //DADOS CLIENTE
        dadosCliente.put(ClienteDataModel.getIdCliente(), cliente.getId());
        dadosCliente.put(ClienteDataModel.getNomeCliente(), cliente.getNome());
        dadosCliente.put(ClienteDataModel.getEmailCliente(), cliente.geteMail());
        dadosCliente.put(ClienteDataModel.getLoginCliente(), cliente.getLogin());
        dadosCliente.put(ClienteDataModel.getSenhaCliente(), cliente.getSenha());
        dadosCliente.put(ClienteDataModel.getTelefoneCliente(), cliente.getTelefone());
        dadosCliente.put(ClienteDataModel.getCelularCliente(), cliente.getCelular());
        dadosCliente.put(ClienteDataModel.getEquipamentoCliente(), cliente.getRoteador());
        dadosCliente.put(ClienteDataModel.getCaboCliente(), cliente.getCabeamento());
        dadosCliente.put(ClienteDataModel.getIdEndereco(), endereco.getId());

        //DADOS ENDEREÇO
        dadosEndereco.put(EnderecoDataModel.getIdEndereco(), endereco.getId());
        dadosEndereco.put(EnderecoDataModel.getRuaEndereco(), endereco.getRua());
        dadosEndereco.put(EnderecoDataModel.getBairroEndereco(), endereco.getBairro());
        dadosEndereco.put(EnderecoDataModel.getNumeroEdenreco(), endereco.getNumero());
        dadosEndereco.put(EnderecoDataModel.getCepEndereco(), endereco.getCep());
        dadosEndereco.put(EnderecoDataModel.getComplementoEndereco(), endereco.getComplemento());
        dadosEndereco.put(EnderecoDataModel.getReferenciaEndereco(), endereco.getReferencia());

       retornoChamado = insert(ChamadosDataModel.getTABELA(), dados);
       retornoCliente = insert(ClienteDataModel.getTabela(), dadosCliente);
       retornoEndereco = insert(EnderecoDataModel.getTabela(), dadosEndereco);

       if(retornoChamado == true && retornoCliente == true && retornoEndereco == true){
           return true;
       }else{
           return false;
       }
    }

}
