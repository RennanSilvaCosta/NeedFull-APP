package tcc.etec.needful.view.view.fragments;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.sundeepk.compactcalendarview.CompactCalendarView;
import com.github.sundeepk.compactcalendarview.domain.Event;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import tcc.etec.needful.R;
import tcc.etec.needful.view.view.adapter.AdapterAgendados;
import tcc.etec.needful.view.view.adapter.RecyclerItemClickListener;
import tcc.etec.needful.view.view.controller.ChamadosController;
import tcc.etec.needful.view.view.model.ChamadosModel;
import tcc.etec.needful.view.view.view.DetalhesChamado;

public class ModeloFragment extends Fragment {

    View view;
    Context context;
    TextView txtMes;
    private AdapterAgendados adapterAgendados;
    private RecyclerView recyclerView;
    private List<ChamadosModel> listaChamados = new ArrayList<>();
    private int idTecnico;
    CompactCalendarView compactCalendarView;
    private long epoch;
    private String mes = "";
    private String dia = "";
    private String ano = "";
    private String dataCompleta = "";

    public ModeloFragment(int id) {
        this.idTecnico = id;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_modelo, container, false);

        context = getContext();
        recyclerView = view.findViewById(R.id.recyclerAgendados);
        compactCalendarView = view.findViewById(R.id.compactcalendar_view);
        txtMes = view.findViewById(R.id.txt_mes);
        compactCalendarView.setUseThreeLetterAbbreviation(false);


        try {
            List<String> listaDatas = new ArrayList<>();
            ChamadosController controller = new ChamadosController(context);
            listaDatas = controller.buscarDatas(idTecnico);
            String teste = "";

            for (String teste1 : listaDatas) {
                teste = teste1;

                for (int i = 0; i < 4; i++) {
                    char c = teste.charAt(i);
                    ano = ano + String.valueOf(c);
                }
                for (int i = 5; i <= 6; i++) {
                    char c = teste.charAt(i);
                    mes = mes + String.valueOf(c);
                }
                for (int i = 8; i < 10; i++) {
                    char c = teste.charAt(i);
                    dia = dia + String.valueOf(c);
                }

                dataCompleta = mes + "/" + dia +"/" + ano;

                this.epoch = new java.text.SimpleDateFormat("MM/dd/yyyy HH:mm:ss").parse(dataCompleta +" 14:30:00").getTime();
                Event ev = new Event(Color.YELLOW, epoch);
                compactCalendarView.addEvent(ev);
                ev =null;
                epoch = 0;
                zerarData();
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }

        compactCalendarView.setListener(new CompactCalendarView.CompactCalendarViewListener() {
            @Override
            public void onDayClick(Date dateClicked) {

                zerarData();
                String dataSelecionada = String.valueOf(dateClicked);
                for (int i = 4; i < 7; i++) {
                    char c = dataSelecionada.charAt(i);
                    mes = mes + String.valueOf(c);
                }
                for (int i = 8; i < 10; i++) {
                    char c = dataSelecionada.charAt(i);
                    dia = dia + String.valueOf(c);
                }
                for (int i = 29; i <= 33; i++) {
                    char c = dataSelecionada.charAt(i);
                    ano = ano + String.valueOf(c);
                }

                dataCompleta = ano.trim() + "-" + mesNumerico(mes) + dia;

                ChamadosController controller = new ChamadosController(context);
                listaChamados = controller.buscarAgendadoPorData(dataCompleta, idTecnico);
                adapterAgendados = new AdapterAgendados(listaChamados, context);
                RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(context);
                recyclerView.setLayoutManager(layoutManager);
                recyclerView.setHasFixedSize(true);
                recyclerView.setAdapter(adapterAgendados);
            }

            @Override
            public void onMonthScroll(Date firstDayOfNewMonth) {


            }
        });

        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(context, recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                ChamadosModel chamadosModel = listaChamados.get(position);
                int idChamado = chamadosModel.getId();
                int idTipoChamado = chamadosModel.getTipoChamado();
                Intent intent = new Intent(getActivity(), DetalhesChamado.class);
                intent.putExtra("id_chamado", idChamado);
                intent.putExtra("id_tipo_chamado", idTipoChamado);
                startActivity(intent);
            }

            @Override
            public void onLongItemClick(View view, int position) {
                registerForContextMenu(recyclerView);
                Toast.makeText(context, "mano tomare que funcione, longooooo", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        }));

        return view;
    }

    private void zerarData() {
        ano = "";
        mes = "";
        dia = "";
        dataCompleta = "";
    }

    private String mesNumerico(String mes){
        if(mes.trim().equals("Jan")){
            return "01-";
        }else if (mes.trim().equals("Feb")){
            return "02-";
        }else if(mes.trim().equals("Mar")){
            return "03-";
        }else if (mes.trim().equals("Apr")){
            return "04-";
        }else if (mes.trim().equals("May")){
            return "05-";
        }else if (mes.trim().equals("Jun")){
            return "06-";
        }else if (mes.trim().equals("Jul")){
            return "07-";
        }else if (mes.trim().equals("Aug")){
            return "08-";
        }else if (mes.trim().equals("Sep")){
            return "09-";
        }else if (mes.trim().equals("Oct")){
            return "10-";
        }else if (mes.trim().equals("Nov")){
            return "11-";
        }else if (mes.trim().equals("Dec")){
            return "12-";
        }
        return null;
    }
}
