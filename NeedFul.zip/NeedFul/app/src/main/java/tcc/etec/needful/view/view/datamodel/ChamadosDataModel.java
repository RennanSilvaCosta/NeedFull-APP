package tcc.etec.needful.view.view.datamodel;

public class ChamadosDataModel {

    private final static String tabela = "chamado";

    private final static String id = "id_chamado";
    private final static String idCliente = "id_cliente";
    private final static String dataChamado = "data_do_chamado";
    private final static String horaChamado = "hora_do_chamado";
    private final static String agendamentoChamado = "agendamento_chamado";
    private final static String observacaoChamado = "observacao_chamado";
    private final static String idTecnico = "id_tecnico";
    private final static String idTipoChamado = "id_tipo_chamado";
    private final static String idStatusChamado = "id_status_chamado";

    private static String comandoSQL = "";

    public static String criarTabela(){

        setComandoSQL("CREATE TABLE "+ getTABELA());
        setComandoSQL(getComandoSQL() + "(");
       setComandoSQL(getComandoSQL() + id + " INTEGER, ");
       setComandoSQL(getComandoSQL() + idCliente + " INTEGER, ");
       setComandoSQL(getComandoSQL() + dataChamado + " DATE, ");
       setComandoSQL(getComandoSQL() + horaChamado + " TIME, ");
       setComandoSQL(getComandoSQL() + agendamentoChamado + " DATE, ");
       setComandoSQL(getComandoSQL() + observacaoChamado +  " TEXT, ");
       setComandoSQL(getComandoSQL() + idTecnico + " INTEGER, ");
       setComandoSQL(getComandoSQL() + idTipoChamado + " INTEGER, ");
       setComandoSQL(getComandoSQL() + idStatusChamado + " INTEGER ");
       setComandoSQL(getComandoSQL() + " );");

        return getComandoSQL();
    }

    public static String getTabela() {
        return tabela;
    }

    public static String getTABELA() {
        return tabela;
    }

    public static String getComandoSQL() {
        return comandoSQL;
    }

    public static void setComandoSQL(String comandoSQL) {
        ChamadosDataModel.comandoSQL = comandoSQL;
    }

    public static String getId() {
        return id;
    }

    public static String getIdCliente() {
        return idCliente;
    }

    public static String getDataChamado() {
        return dataChamado;
    }

    public static String getHoraChamado() {
        return horaChamado;
    }

    public static String getAgendamentoChamado() {
        return agendamentoChamado;
    }

    public static String getObservacaoChamado() {
        return observacaoChamado;
    }

    public static String getIdTecnico() {
        return idTecnico;
    }

    public static String getIdTipoChamado() {
        return idTipoChamado;
    }

    public static String getIdStatusChamado() {
        return idStatusChamado;
    }
}
