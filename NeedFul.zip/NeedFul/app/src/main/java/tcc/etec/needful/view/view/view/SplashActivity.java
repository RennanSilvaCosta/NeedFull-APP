package tcc.etec.needful.view.view.view;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Retrofit;
import tcc.etec.needful.R;
import tcc.etec.needful.view.view.api.WebService;
import tcc.etec.needful.view.view.api.WebServiceChamado;
import tcc.etec.needful.view.view.controller.ChamadosController;
import tcc.etec.needful.view.view.datamodel.ChamadosDataModel;
import tcc.etec.needful.view.view.datamodel.ClienteDataModel;
import tcc.etec.needful.view.view.datamodel.EnderecoDataModel;
import tcc.etec.needful.view.view.datamodel.UsuarioDataModel;
import tcc.etec.needful.view.view.model.ChamadosModel;
import tcc.etec.needful.view.view.model.ClienteModel;
import tcc.etec.needful.view.view.model.EnderecoModel;
import tcc.etec.needful.view.view.model.UsuarioModel;
import tcc.etec.needful.view.view.util.UtilChamados;
import tcc.etec.needful.view.view.util.UtilUser;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_TIME_OUT = 3000;
    ChamadosController controller;
    Context context;
    private Retrofit retrofit;
    private List<ChamadosModel> listaChamados = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        context = getBaseContext();
        controller = new ChamadosController(context);
        apresentarTelaSplash();

    }

    private void apresentarTelaSplash() {

        /*retrofit = new Retrofit.Builder()
                .baseUrl("localhost:8080/WSNeedful/webresources/")
                .addConverterFactory(GsonConverterFactory.create()).build();*/

        //sincronizarChamados();

        SplashActivity.SincronizarChamados sincChamados = new SplashActivity.SincronizarChamados();
        sincChamados.execute();

        SplashActivity.SincronizarUsers sincUsers = new SplashActivity.SincronizarUsers();
        sincUsers.execute();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent telaPrincipal = new Intent(SplashActivity.this, UserLoginActivity.class);
                startActivity(telaPrincipal);
                finish();

            }
        }, SPLASH_TIME_OUT);

    }

    private void sincronizarChamados() {

        Gson gson = new Gson();
        WebServiceChamado webServiceChamado = new WebServiceChamado();
        ChamadosModel chamadosModel = new ChamadosModel();
        ClienteModel clienteModel = new ClienteModel();
        clienteModel.setNome("");
        chamadosModel.setClientVO(clienteModel);

        try {
            List<ChamadosModel> t =  webServiceChamado.listagempost(chamadosModel);
            for (ChamadosModel c : t) {
                System.out.println(c.toString());
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private class SincronizarUsers extends AsyncTask<String, String, String> {

        ProgressDialog progressDialog = new ProgressDialog(SplashActivity.this);

        HttpURLConnection connection;
        URL url = null;
        Uri.Builder builder;

        public SincronizarUsers() {

            this.builder = new Uri.Builder();
            builder.appendQueryParameter("app", "NeedFul");

        }

        @Override
        protected String doInBackground(String... strings) {

            //montar a URL com o endereço do script PHP

            try {

                url = new URL(UtilUser.URL_WEB_SERVICE + "APIUserLogin.php");

            } catch (MalformedURLException e) {

                Log.e("Web Service ", "MalformedURLException - " + e.getMessage());

            } catch (Exception erro) {

                Log.e("Web Service ", "Exception - " + erro.getMessage());

            }

            try {

                connection = (HttpURLConnection) url.openConnection();
                connection.setReadTimeout(UtilUser.READ_TIMEOUT);
                connection.setConnectTimeout(UtilUser.CONNECTION_TIMEOUT);
                connection.setRequestMethod("POST");
                connection.setRequestProperty("charset", "utf-8");

                connection.setDoInput(true);
                connection.setDoOutput(true);

                connection.connect();

                String query = builder.build().getEncodedQuery();

                OutputStream os = connection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
                connection.connect();


            } catch (IOException e) {

                Log.e("Web Service ", "IOException - " + e.getMessage());
            }

            try {

                int response_code = connection.getResponseCode();

                if (response_code == HttpURLConnection.HTTP_OK) {

                    InputStream input = connection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    StringBuilder resultado = new StringBuilder();


                    String linha;

                    while ((linha = reader.readLine()) != null) {
                        resultado.append(linha);
                    }
                    return resultado.toString();
                } else {
                    return "Erro de conexão";
                }

            } catch (IOException e) {

                Log.e("WebService", "IOException - " + e.getMessage());

                return e.toString();

            } finally {

                connection.disconnect();
            }

        }


        @Override
        protected void onPostExecute(String result) {


            try {

                JSONArray jArray = new JSONArray(result);

                if (jArray.length() != 0) {

                    controller.deletarTabela(UsuarioDataModel.getTABELA());
                    controller.criarTabela(UsuarioDataModel.criarTabela());

                    for (int i = 0; i < jArray.length(); i++) {

                        JSONObject jsonObject = jArray.getJSONObject(i);

                        UsuarioModel obj = new UsuarioModel();

                        obj.setIdUsuario(jsonObject.getInt(UsuarioDataModel.getId()));
                        obj.setNomeUsuario(jsonObject.getString(UsuarioDataModel.getNome()));
                        obj.setEmailUsuario(jsonObject.getString(UsuarioDataModel.getEmail()));
                        obj.setCpfUsuario(jsonObject.getString(UsuarioDataModel.getCpf()));
                        obj.setLoginUsuario(jsonObject.getString(UsuarioDataModel.getLogin()));
                        obj.setSenhaUsuario(jsonObject.getString(UsuarioDataModel.getSenha()));
                        obj.setIdTipoUsuario(jsonObject.getInt(UsuarioDataModel.getTipo_usuario()));

                        controller.salvarUser(obj);
                    }


                } else {


                }

            } catch (JSONException e) {

                Log.e("WebService", "erro JSONException - " + e.getMessage());

            } finally {

                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();


                }

            }


        }

    }

    private class SincronizarChamados extends AsyncTask<String, String, String> {

        ProgressDialog progressDialog = new ProgressDialog(SplashActivity.this);
        HttpURLConnection connection;
        URL url = null;
        Uri.Builder builder;

        public SincronizarChamados() {

            this.builder = new Uri.Builder();
            builder.appendQueryParameter("app", "NeedFul");

        }

        @Override
        protected String doInBackground(String... strings) {

            //montar a URL com o endereço do script PHP

            try {

                url = new URL(UtilChamados.URL_WEB_SERVICE + "APISincronizarSistema.php");

            } catch (MalformedURLException e) {

                Log.e("Web Service ", "MalformedURLException - " + e.getMessage());

            } catch (Exception erro) {

                Log.e("Web Service ", "Exception - " + erro.getMessage());

            }

            try {

                connection = (HttpURLConnection) url.openConnection();
                connection.setReadTimeout(UtilChamados.READ_TIMEOUT);
                connection.setConnectTimeout(UtilChamados.CONNECTION_TIMEOUT);
                connection.setRequestMethod("POST");
                connection.setRequestProperty("charset", "UTF-8");
                connection.setDoInput(true);
                connection.setDoOutput(true);
                connection.connect();

                String query = builder.build().getEncodedQuery();

                OutputStream os = connection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
                connection.connect();

            } catch (IOException e) {

                Log.e("Web Service ", "IOException - " + e.getMessage());
            }

            try {

                int response_code = connection.getResponseCode();

                if (response_code == HttpURLConnection.HTTP_OK) {

                    InputStream input = connection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    StringBuilder resultado = new StringBuilder();

                    String linha;

                    while ((linha = reader.readLine()) != null) {
                        resultado.append(linha);
                    }
                    return resultado.toString();
                } else {
                    return "Erro de conexão";
                }

            } catch (IOException e) {

                Log.e("WebService", "IOException - " + e.getMessage());

                return e.toString();

            } finally {

                connection.disconnect();
            }
        }

        @Override
        protected void onPostExecute(String result) {

            try {

                JSONArray jArray = new JSONArray(result);

                if (jArray.length() != 0) {

                    controller.deletarTabela(ChamadosDataModel.getTABELA());
                    controller.deletarTabela(ClienteDataModel.getTabela());
                    controller.deletarTabela(EnderecoDataModel.getTabela());

                    controller.criarTabela(ChamadosDataModel.criarTabela());
                    controller.criarTabela(ClienteDataModel.criarTabela());
                    controller.criarTabela(EnderecoDataModel.criarTabela());

                    for (int i = 0; i < jArray.length(); i++) {

                        JSONObject jsonObject = jArray.getJSONObject(i);

                        ChamadosModel chamados = new ChamadosModel();
                        ClienteModel cliente = new ClienteModel();
                        EnderecoModel endereco = new EnderecoModel();

                        //chamado
                        chamados.setId(jsonObject.getInt(ChamadosDataModel.getId()));
                        chamados.setData(Date.valueOf(jsonObject.getString(ChamadosDataModel.getDataChamado())));
                        chamados.setHoras(Time.valueOf(jsonObject.getString(ChamadosDataModel.getHoraChamado())));
                        chamados.setAgendamento(Date.valueOf(jsonObject.getString(ChamadosDataModel.getAgendamentoChamado())));
                        chamados.setDescricao(jsonObject.getString(ChamadosDataModel.getObservacaoChamado()));
                        chamados.setIdTecnico(jsonObject.getInt(ChamadosDataModel.getIdTecnico()));
                        chamados.setTipoChamado(jsonObject.getInt(ChamadosDataModel.getIdTipoChamado()));
                        chamados.setIdStatusChamado(jsonObject.getInt(ChamadosDataModel.getIdStatusChamado()));

                        //cliente
                        cliente.setId(jsonObject.getInt(ClienteDataModel.getIdCliente()));
                        cliente.setNome(jsonObject.getString(ClienteDataModel.getNomeCliente()));
                        cliente.seteMail(jsonObject.getString(ClienteDataModel.getEmailCliente()));
                        cliente.setLogin(jsonObject.getString(ClienteDataModel.getLoginCliente()));
                        cliente.setSenha(jsonObject.getString(ClienteDataModel.getSenhaCliente()));
                        cliente.setTelefone(jsonObject.getString(ClienteDataModel.getTelefoneCliente()));
                        cliente.setCelular(jsonObject.getString(ClienteDataModel.getCelularCliente()));
                        cliente.setRoteador(jsonObject.getString(ClienteDataModel.getEquipamentoCliente()));
                        cliente.setCabeamento(jsonObject.getString(ClienteDataModel.getCaboCliente()));

                        //endereco
                        endereco.setId(jsonObject.getInt(EnderecoDataModel.getIdEndereco()));
                        endereco.setRua(jsonObject.getString(EnderecoDataModel.getRuaEndereco()));
                        endereco.setBairro(jsonObject.getString(EnderecoDataModel.getBairroEndereco()));
                        endereco.setNumero(jsonObject.getString(EnderecoDataModel.getNumeroEdenreco()));
                        endereco.setCep(jsonObject.getString(EnderecoDataModel.getCepEndereco()));
                        endereco.setComplemento(jsonObject.getString(EnderecoDataModel.getComplementoEndereco()));
                        endereco.setReferencia(jsonObject.getString(EnderecoDataModel.getReferenciaEndereco()));

                        cliente.setEnderecoModel(endereco);
                        chamados.setClientVO(cliente);

                        controller.salvar(chamados,cliente,endereco);

                    }

                } else {

                    Toast.makeText(context , "Nenhum registro encontrado", Toast.LENGTH_LONG).show();
                }

            } catch (JSONException e) {

                Log.e("WebService", "erro JSONException - " + e.getMessage());

            } finally {

                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();


                }

            }


        }

    }

}
