package tcc.etec.needful.view.view.view;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.util.Log;
import android.view.View;

import com.google.android.material.navigation.NavigationView;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import tcc.etec.needful.R;
import tcc.etec.needful.view.view.controller.ChamadosController;
import tcc.etec.needful.view.view.datamodel.ChamadosDataModel;
import tcc.etec.needful.view.view.datamodel.ClienteDataModel;
import tcc.etec.needful.view.view.datamodel.EnderecoDataModel;
import tcc.etec.needful.view.view.fragments.ChamadosFragment;
import tcc.etec.needful.view.view.fragments.ConfigFragment;
import tcc.etec.needful.view.view.fragments.ModeloFragment;
import tcc.etec.needful.view.view.fragments.AgendadosFragment;
import tcc.etec.needful.view.view.fragments.StatusFragment;
import tcc.etec.needful.view.view.fragments.FinalizadosFragment;
import tcc.etec.needful.view.view.model.ChamadosModel;
import tcc.etec.needful.view.view.model.ClienteModel;
import tcc.etec.needful.view.view.model.EnderecoModel;
import tcc.etec.needful.view.view.util.UtilChamados;

import android.view.Menu;
import android.view.MenuItem;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Date;
import java.sql.Time;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    FragmentManager fragmentManager;
    ChamadosController controller;
    Context context;

    private String nome;
    private int idTecnico;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        context = getBaseContext();
        controller = new ChamadosController(context);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Sincronização do sistema", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

                SincronizarChamados task = new SincronizarChamados();
                task.execute();

            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        Intent intent = getIntent();
        this.idTecnico = intent.getIntExtra("id_tecnico", 0 );

        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.content_fragment, new ModeloFragment(this.idTecnico)).commit();

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_sair) {

            finish();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();


        if (id == R.id.nav_home) {

            setTitle("NeedFul");

            fragmentManager.beginTransaction().replace(R.id.content_fragment, new ModeloFragment(this.idTecnico)).commit();


        } else if (id == R.id.nav_chamados) {

            setTitle("Chamados");

            fragmentManager.beginTransaction().replace(R.id.content_fragment, new ChamadosFragment(this.idTecnico)).commit();


        } else if (id == R.id.nav_agendados) {

            setTitle("Agendados");

            fragmentManager.beginTransaction().replace(R.id.content_fragment, new AgendadosFragment(this.idTecnico)).commit();

        } else if (id == R.id.nav_finalizados) {

            setTitle("Chamados Finalizados");

            fragmentManager.beginTransaction().replace(R.id.content_fragment, new FinalizadosFragment(this.idTecnico)).commit();


        } else if (id == R.id.nav_status) {

            setTitle("Status");

            fragmentManager.beginTransaction().replace(R.id.content_fragment, new StatusFragment(this.idTecnico)).commit();


        } else if (id == R.id.nav_config) {

            setTitle("Configurações");

            fragmentManager.beginTransaction().replace(R.id.content_fragment, new ConfigFragment()).commit();

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private class SincronizarChamados extends AsyncTask<String, String, String> {

        ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);

        HttpURLConnection connection;
        URL url = null;
        Uri.Builder builder;


        public SincronizarChamados() {

            this.builder = new Uri.Builder();
            builder.appendQueryParameter("app", "NeedFul");

        }

        @Override
        protected void onPreExecute() {

            progressDialog.setMessage("Sincronizando...");
            progressDialog.setCancelable(false);
            progressDialog.show();

        }

        @Override
        protected String doInBackground(String... strings) {

            //montar a URL com o endereço do script PHP

            try {

                url = new URL(UtilChamados.URL_WEB_SERVICE + "APISincronizarSistema.php");

            } catch (MalformedURLException e) {

                Log.e("Web Service ", "MalformedURLException - " + e.getMessage());

            } catch (Exception erro) {

                Log.e("Web Service ", "Exception - " + erro.getMessage());

            }

            try {

                connection = (HttpURLConnection) url.openConnection();
                connection.setReadTimeout(UtilChamados.READ_TIMEOUT);
                connection.setConnectTimeout(UtilChamados.CONNECTION_TIMEOUT);
                connection.setRequestMethod("POST");
                connection.setRequestProperty("charset", "utf-8");

                connection.setDoInput(true);
                connection.setDoOutput(true);

                connection.connect();

                String query = builder.build().getEncodedQuery();

                OutputStream os = connection.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();
                connection.connect();


            } catch (IOException e) {

                Log.e("Web Service ", "IOException - " + e.getMessage());
            }

            try{

                int response_code = connection.getResponseCode();

                if(response_code == HttpURLConnection.HTTP_OK){

                    InputStream input = connection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                    StringBuilder resultado = new StringBuilder();


                    String linha;

                    while((linha = reader.readLine()) != null){
                        resultado.append(linha);
                    }
                    return resultado.toString();
                }else{
                    return "Erro de conexão";
                }

            }catch (IOException e){

                Log.e("WebService","IOException - "+e.getMessage());

                return e.toString();

            }finally{

                connection.disconnect();
            }

        }

        @Override
        protected void onPostExecute(String result) {

            try{

                JSONArray jArray = new JSONArray(result);

                if(jArray.length() != 0){

                    controller.deletarTabela(ChamadosDataModel.getTABELA());
                    controller.deletarTabela(ClienteDataModel.getTabela());
                    controller.deletarTabela(EnderecoDataModel.getTabela());

                    controller.criarTabela(ChamadosDataModel.criarTabela());
                    controller.criarTabela(ClienteDataModel.criarTabela());
                    controller.criarTabela(EnderecoDataModel.criarTabela());

                    for (int i = 0; i < jArray.length(); i++){

                        JSONObject jsonObject = jArray.getJSONObject(i);

                        ChamadosModel chamados = new ChamadosModel();
                        ClienteModel cliente = new ClienteModel();
                        EnderecoModel endereco = new EnderecoModel();

                        //chamado
                        chamados.setId(jsonObject.getInt(ChamadosDataModel.getId()));
                        chamados.setData(Date.valueOf(jsonObject.getString(ChamadosDataModel.getDataChamado())));
                        chamados.setHoras(Time.valueOf(jsonObject.getString(ChamadosDataModel.getHoraChamado())));
                        chamados.setAgendamento(Date.valueOf(jsonObject.getString(ChamadosDataModel.getAgendamentoChamado())));
                        chamados.setDescricao(jsonObject.getString(ChamadosDataModel.getObservacaoChamado()));
                        chamados.setIdTecnico(jsonObject.getInt(ChamadosDataModel.getIdTecnico()));
                        chamados.setTipoChamado(jsonObject.getInt(ChamadosDataModel.getIdTipoChamado()));
                        chamados.setIdStatusChamado(jsonObject.getInt(ChamadosDataModel.getIdStatusChamado()));


                        //cliente
                        cliente.setId(jsonObject.getInt(ClienteDataModel.getIdCliente()));
                        cliente.setNome(jsonObject.getString(ClienteDataModel.getNomeCliente()));
                        cliente.seteMail(jsonObject.getString(ClienteDataModel.getEmailCliente()));
                        cliente.setLogin(jsonObject.getString(ClienteDataModel.getLoginCliente()));
                        cliente.setSenha(jsonObject.getString(ClienteDataModel.getSenhaCliente()));
                        cliente.setTelefone(jsonObject.getString(ClienteDataModel.getTelefoneCliente()));
                        cliente.setCelular(jsonObject.getString(ClienteDataModel.getCelularCliente()));
                        cliente.setRoteador(jsonObject.getString(ClienteDataModel.getEquipamentoCliente()));
                        cliente.setCabeamento(jsonObject.getString(ClienteDataModel.getCaboCliente()));

                        //endereco
                        endereco.setId(jsonObject.getInt(EnderecoDataModel.getIdEndereco()));
                        endereco.setRua(jsonObject.getString(EnderecoDataModel.getRuaEndereco()));
                        endereco.setBairro(jsonObject.getString(EnderecoDataModel.getBairroEndereco()));
                        endereco.setNumero(jsonObject.getString(EnderecoDataModel.getNumeroEdenreco()));
                        endereco.setCep(jsonObject.getString(EnderecoDataModel.getCepEndereco()));
                        endereco.setComplemento(jsonObject.getString(EnderecoDataModel.getComplementoEndereco()));
                        endereco.setReferencia(jsonObject.getString(EnderecoDataModel.getReferenciaEndereco()));

                        cliente.setEnderecoModel(endereco);
                        chamados.setClientVO(cliente);


                        controller.salvar(chamados, cliente, endereco);
                    }


                }else{

                    //Toast.makeText(context , "Nenhum registro encontrado", Toast.LENGTH_LONG).show();
                }

            }catch (JSONException e){

                Log.e("WebService", "erro JSONException - " + e.getMessage());

            }finally {

                if(progressDialog != null && progressDialog.isShowing()){
                    progressDialog.dismiss();


                }

            }


        }

    }

}
