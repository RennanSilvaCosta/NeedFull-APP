package tcc.etec.needful.view.view.util;

public class UtilUser {

    public static final String URL_WEB_SERVICE = "https://rennancosta.000webhostapp.com/";

    public static final int CONNECTION_TIMEOUT = 10000;

    public static final int READ_TIMEOUT = 15000;

}
