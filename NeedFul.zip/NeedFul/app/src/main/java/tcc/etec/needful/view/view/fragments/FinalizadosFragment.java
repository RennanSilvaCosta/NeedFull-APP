package tcc.etec.needful.view.view.fragments;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import tcc.etec.needful.R;
import tcc.etec.needful.view.view.adapter.FinalizadosListAdapter;
import tcc.etec.needful.view.view.controller.ChamadosController;
import tcc.etec.needful.view.view.model.ChamadosModel;
import tcc.etec.needful.view.view.view.DetalhesChamado;


public class FinalizadosFragment extends Fragment {

    ArrayList<ChamadosModel> dataSet;
    ListView listView;
    View view;
    private int idTecnico;

    public FinalizadosFragment(int id_tecnico) {
        this.idTecnico = id_tecnico;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_finalizados, container, false);

        ChamadosController controller = new ChamadosController(getContext());

        listView = view.findViewById(R.id.listView);
        dataSet = controller.listarFinalizados(this.idTecnico);
        FinalizadosListAdapter adapter = new FinalizadosListAdapter(dataSet, getContext());
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                ChamadosModel chamadosModel = dataSet.get(position);

                if (chamadosModel.getTipoChamado() == 1) {

                    int idChamado = chamadosModel.getId();
                    int idTipoChamado = chamadosModel.getTipoChamado();
                    Intent intent = new Intent(getActivity(), DetalhesChamado.class);
                    intent.putExtra("id_chamado", idChamado);
                    intent.putExtra("id_tipo_chamado", idTipoChamado);
                    startActivity(intent);

                } else if (chamadosModel.getTipoChamado() == 2) {

                    int idChamado = chamadosModel.getId();
                    int idTipoChamado = chamadosModel.getTipoChamado();
                    Intent intent = new Intent(getActivity(), DetalhesChamado.class );
                    intent.putExtra("id_chamado", idChamado);
                    intent.putExtra("id_tipo_chamado", idTipoChamado);
                    startActivity(intent);
                }
            }
        });

        return view;
    }

}
