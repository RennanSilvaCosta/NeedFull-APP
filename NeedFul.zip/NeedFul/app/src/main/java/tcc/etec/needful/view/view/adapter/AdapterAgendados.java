package tcc.etec.needful.view.view.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;
import tcc.etec.needful.R;
import tcc.etec.needful.view.view.model.ChamadosModel;


public class AdapterAgendados extends RecyclerView.Adapter<AdapterAgendados.MyViewHolder> {

    List<ChamadosModel> chamados;
    Context context;

    public AdapterAgendados(List<ChamadosModel> chamados, Context context) {
        this.chamados = chamados;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemLista = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_agendados, parent, false);
        return new MyViewHolder(itemLista);
    }


    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        ChamadosModel chamadosModel = chamados.get(position);

            holder.tipoChamado.setText(tipoChamado(chamadosModel.getTipoChamado()));
            holder.data.setText(String.valueOf(chamadosModel.getAgendamento()));
            holder.hora.setText(String.valueOf(chamadosModel.getHoras()));
            holder.nome.setText(chamadosModel.getClientVO().getNome());
            holder.endereco.setText(chamadosModel.getClientVO().getEnderecoModel().getBairro() + ", "+ chamadosModel.getClientVO().getEnderecoModel().getNumero());

    }

    @Override
    public int getItemCount() {
        return chamados.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tipoChamado, data, hora, endereco, nome;

        public MyViewHolder(View itemView) {
            super(itemView);

            tipoChamado = itemView.findViewById(R.id.textAdapterTipoChamado);
            data = itemView.findViewById(R.id.textAdapterData);
            hora = itemView.findViewById(R.id.textAdapterHora);
            endereco = itemView.findViewById(R.id.textAdapterEndereco);
            nome = itemView.findViewById(R.id.textAdapterNome);

        }

    }
    private String tipoChamado(int tipoChamado) {

        if (tipoChamado == 1) {
            return "Instalação";
        } else if (tipoChamado == 2) {
            return "Manutenção";
        }
        return null;
    }
}
