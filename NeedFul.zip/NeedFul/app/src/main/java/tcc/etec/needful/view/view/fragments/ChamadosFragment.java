package tcc.etec.needful.view.view.fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.fragment.app.Fragment;
import tcc.etec.needful.R;
import tcc.etec.needful.view.view.adapter.ChamadosListAdapter;
import tcc.etec.needful.view.view.controller.ChamadosController;
import tcc.etec.needful.view.view.model.ChamadosModel;
import tcc.etec.needful.view.view.view.DetalhesChamado;


public class ChamadosFragment extends Fragment {


    TextView textoFundo;
    ImageView imgFundo;
    AlertDialog.Builder build;
    AlertDialog alert;
    ArrayList<ChamadosModel> dataSet;
    ListView listView;
    Context context;
    ChamadosController controller;
    private int idTecnico;

    View view;

    public ChamadosFragment(int id_tecnico) {
        this.idTecnico = id_tecnico;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_chamados, container, false);

        context = getContext();
        controller = new ChamadosController(getContext());
        listView = view.findViewById(R.id.listVieew);
        dataSet = controller.todosChamados(this.idTecnico);
        ChamadosListAdapter adapter = new ChamadosListAdapter(dataSet, getContext());
        listView.setAdapter(adapter);
        listView.setLongClickable(true);

        habilitarFundo();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ChamadosModel chamadosModel = dataSet.get(position);

                if (chamadosModel.getTipoChamado() == 1) {

                    int idChamado = chamadosModel.getId();
                    int idTipoChamado = chamadosModel.getTipoChamado();
                    Intent intent = new Intent(getActivity(), DetalhesChamado.class);
                    intent.putExtra("id_chamado", idChamado);
                    intent.putExtra("id_tipo_chamado", idTipoChamado);
                    startActivity(intent);

                } else if (chamadosModel.getTipoChamado() == 2) {

                    int idChamado = chamadosModel.getId();
                    int idTipoChamado = chamadosModel.getTipoChamado();
                    Intent intent = new Intent(getActivity(), DetalhesChamado.class);
                    intent.putExtra("id_chamado", idChamado);
                    intent.putExtra("id_tipo_chamado", idTipoChamado);
                    startActivity(intent);

                }
            }
        });

        registerForContextMenu(listView);

        return view;
    }

    private void habilitarFundo() {
        imgFundo = view.findViewById(R.id.imgFundo);
        textoFundo = view.findViewById(R.id.txtFundo);
        if(dataSet.size() == 0){
            imgFundo.setVisibility(View.VISIBLE);
            textoFundo.setVisibility(View.VISIBLE);
        }else{
            imgFundo.setVisibility(View.INVISIBLE);
            textoFundo.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflater = getActivity().getMenuInflater();
        inflater.inflate(R.menu.menu_flutuante, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

        switch (item.getItemId()) {
            case R.id.opcao_1:
                int position = info.position;
                ChamadosModel chamadosModel = dataSet.get(position);
                chamadosModel.setIdStatusChamado(5);
                controller.alterar(chamadosModel);
                atualizarLista();
                return true;

            case R.id.opcao_2:

                return true;
            default:
                return super.onContextItemSelected(item);

        }

    }

    @Override
    public void onResume() {
        super.onResume();
        atualizarLista();
    }

    @Override
    public void onPause() {
        super.onPause();
        atualizarLista();
    }

    private void atualizarLista(){

        context = getContext();
        controller = new ChamadosController(getContext());
        listView = view.findViewById(R.id.listVieew);
        dataSet = controller.todosChamados(this.idTecnico);
        ChamadosListAdapter adapter = new ChamadosListAdapter(dataSet, getContext());
        listView.setAdapter(adapter);
        listView.setLongClickable(true);

    }

}
