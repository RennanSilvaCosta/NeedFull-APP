package tcc.etec.needful.view.view.adapter;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import tcc.etec.needful.R;
import tcc.etec.needful.view.view.controller.ChamadosController;
import tcc.etec.needful.view.view.model.ChamadosModel;
import tcc.etec.needful.view.view.util.AlterarAsynTask;
import tcc.etec.needful.view.view.util.UtilChamados;

public class  ChamadosListAdapter extends ArrayAdapter<ChamadosModel> implements View.OnClickListener {

    Context context;
    AlertDialog.Builder build;
    AlertDialog alert;
    ChamadosController controller;

    //private int ultimaPosicao = -1;
    ArrayList<ChamadosModel> dados;

    private static class ViewHolder {
        TextView txt_Tipo_Chamado;
        TextView txt_Nome_Cliente;
        TextView txt_Endereco_cliente;
        ImageView img_logo;
        ImageView img_finalizar;
    }

    public ChamadosListAdapter(ArrayList<ChamadosModel> dataSet, Context context) {
        super(context, R.layout.list_view_chamados_fragment, dataSet);

        this.dados = dataSet;
        this.context = context;

    }

    @Override
    public void onClick(View view) {

        int posicao = (Integer) view.getTag();
        Object object = getItem(posicao);
        final ChamadosModel chamadosModel = (ChamadosModel) object;

        switch (view.getId()) {

            case R.id.img_tipo_instalacao:
              if (chamadosModel.getIdStatusChamado() == 2) {

                    Snackbar.make(view, "Nova Manutenção:" + "\n" + chamadosModel.getClientVO().getEnderecoModel().getRua() ,
                            Snackbar.LENGTH_LONG)
                            .setAction("No action", null).show();
                } else {

                    Snackbar.make(view, "Nova Instalação:" + "\n" + chamadosModel.getClientVO().getEnderecoModel().getRua() ,
                            Snackbar.LENGTH_LONG)
                            .setAction("No action", null).show();
                }
                break;

            case R.id.imgFinalizar_chamados:

                if(chamadosModel.getIdStatusChamado() == 2 ){
                    build = new AlertDialog.Builder(getContext());
                    build.setTitle("ALERTA");
                    build.setMessage("Deseja FINALIZAR este chamado?");
                    build.setCancelable(true);
                    build.setIcon(R.mipmap.ic_launcher);

                    build.setPositiveButton("SIM", new Dialog.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            chamadosModel.setIdStatusChamado(4);
                            ChamadosController controller = new ChamadosController(getContext());
                            controller.alterar(chamadosModel);

                            AlterarAsynTask alterar = new AlterarAsynTask(chamadosModel, context);
                            alterar.execute();

                            atualizarLista(controller.todosChamados(chamadosModel.getIdTecnico()));
                            Toast.makeText(context,"Chamado finalizado com sucesso!",Toast.LENGTH_SHORT).show();

                        }

                    });

                    build.setNegativeButton("CANCELAR", new Dialog.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            dialog.cancel();
                        }
                    });
                    alert = build.create();
                    alert.show();

                }else if(chamadosModel.getIdStatusChamado() == 4){

                    Snackbar.make(view, "Chamado Finalizado: " ,
                            Snackbar.LENGTH_LONG)
                            .setAction("No action", null).show();

                }else if (chamadosModel.getIdStatusChamado() == 5){

                    build = new AlertDialog.Builder(getContext());
                    build.setTitle("ALERTA");
                    build.setMessage("Este chamado está bloqueado. Você pode desbloquea-lo ou cancela-lo.");
                    build.setCancelable(true);
                    build.setIcon(R.mipmap.ic_launcher);

                    build.setPositiveButton("DESBLOQUEAR", new Dialog.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            chamadosModel.setIdStatusChamado(1);
                            ChamadosController controller = new ChamadosController(getContext());
                            controller.alterar(chamadosModel);

                            AlterarAsynTask alterar = new AlterarAsynTask(chamadosModel, context);
                            alterar.execute();

                            atualizarLista(controller.todosChamados(chamadosModel.getIdTecnico()));
                            Toast.makeText(context,"Chamado desbloqueado com sucesso!",Toast.LENGTH_SHORT).show();

                        }

                    });

                    build.setNeutralButton("CANCELAR", new Dialog.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            chamadosModel.setIdStatusChamado(6);
                            ChamadosController controller = new ChamadosController(getContext());
                            controller.alterar(chamadosModel);

                            AlterarAsynTask alterar = new AlterarAsynTask(chamadosModel, context);
                            alterar.execute();

                            atualizarLista(controller.todosChamados(chamadosModel.getIdTecnico()));
                            Toast.makeText(context,"Chamado cancelado com sucesso!",Toast.LENGTH_SHORT).show();

                        }

                    });

                    build.setNegativeButton("SAIR", new Dialog.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            dialog.cancel();
                        }
                    });
                    alert = build.create();
                    alert.show();

                }
                break;
        }
    }

    @NonNull
    @Override
    public View getView(int position,
                        View dataSet,
                        @NonNull ViewGroup parent) {

        ChamadosModel chamadosModel = getItem(position);
        ViewHolder linha;
        if (dataSet == null) {

            linha = new ViewHolder();

            LayoutInflater layoutChamadoslList = LayoutInflater.from(getContext());

            dataSet = layoutChamadoslList.inflate(R.layout.list_view_chamados_fragment,
                    parent,
                    false);

            linha.txt_Tipo_Chamado = dataSet.findViewById(R.id.txt_tipo_chamado);
            linha.txt_Nome_Cliente = dataSet.findViewById(R.id.txt_nome_cliente);
            linha.txt_Endereco_cliente = dataSet.findViewById(R.id.txt_end_cliente);
            linha.img_logo = dataSet.findViewById(R.id.img_tipo_instalacao);
            linha.img_finalizar = dataSet.findViewById(R.id.imgFinalizar_chamados);

            dataSet.setTag(linha);

        } else {
            linha = (ViewHolder) dataSet.getTag();
        }

        linha.txt_Tipo_Chamado.setText(tipoChamado(chamadosModel.getTipoChamado()));
        linha.txt_Nome_Cliente.setText(chamadosModel.getClientVO().getNome());
        linha.txt_Endereco_cliente.setText(chamadosModel.getClientVO().getEnderecoModel().getRua());

        if (chamadosModel.getIdStatusChamado() == 3) {

            linha.img_finalizar.setVisibility(View.VISIBLE);
            linha.img_finalizar.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_chamado_atrasado));

        }else if (chamadosModel.getIdStatusChamado() == 4){

            linha.img_finalizar.setVisibility(View.VISIBLE);
            linha.img_logo.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_img_logo_chamado_finalizado));
            linha.img_finalizar.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_chamado_finalizado));

        }else if (chamadosModel.getIdStatusChamado() == 2){

            linha.img_finalizar.setVisibility(View.VISIBLE);
            linha.img_logo.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_img_logo_chamado_andamento));
            linha.img_finalizar.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_chamado_andamento));

        }else if (chamadosModel.getIdStatusChamado() == 5){

            linha.img_finalizar.setVisibility(View.VISIBLE);
            linha.img_logo.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_img_logo_chamado_bloqueado));
            linha.img_finalizar.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_chamado_bloqueado));
        }

        linha.img_logo.setOnClickListener(this);
        linha.img_logo.setTag(position);
        linha.img_finalizar.setOnClickListener(this);
        linha.img_finalizar.setTag(position);

        return dataSet;
    }

    private void atualizarLista(ArrayList<ChamadosModel> novosDados) {
        this.dados.clear();
        this.dados.addAll(novosDados);
        notifyDataSetChanged();
    }

    private String tipoChamado(int tipoChamado){

        if(tipoChamado == 1){
            return "Instalação";
        }else if (tipoChamado == 2){
            return "Manutenção";
        }
        return null;
    }

}
