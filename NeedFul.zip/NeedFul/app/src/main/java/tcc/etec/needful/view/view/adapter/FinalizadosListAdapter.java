package tcc.etec.needful.view.view.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import tcc.etec.needful.R;
import tcc.etec.needful.view.view.model.ChamadosModel;
import tcc.etec.needful.view.view.util.UtilChamados;

public class FinalizadosListAdapter extends ArrayAdapter<ChamadosModel> implements View.OnClickListener {

    Context context;
    ArrayList<ChamadosModel> dados;
    AlertDialog.Builder build;
    AlertDialog alert;
    UtilChamados util = new UtilChamados();

    private static class ViewHolder {

        TextView txt_tipo_chamado;
        TextView txt_nome_cliente;
        TextView txt_endereco_cliente;
        TextView txt_data_marcada;
        ImageView img_tipo_chamado;
        ImageView img_finalizar_chamado;
    }


    public FinalizadosListAdapter(ArrayList<ChamadosModel> dataSet, Context context) {
        super(context, R.layout.list_view_finalizados_fragment, dataSet);

        this.dados = dataSet;
        this.context = context;

    }

    @Override
    public void onClick(View view) {

        int posicao = (Integer) view.getTag();

        Object object = getItem(posicao);

        final ChamadosModel chamadosModel = (ChamadosModel) object;

        switch (view.getId()) {

            case R.id.img_tipo_chamado:
                if(chamadosModel.getIdStatusChamado() == 4) {

                   if (chamadosModel.getTipoChamado() == 2) {

                        Snackbar.make(view, "Manutenção finalizada"  /*COLOCAR DATA E HORA DA FINALIAÇÃO DO CHAMADO*/,
                                Snackbar.LENGTH_LONG)
                                .setAction("No action", null).show();

                    } else{

                        Snackbar.make(view, "Instalação finalizada" ,
                                Snackbar.LENGTH_LONG)
                                .setAction("No action", null).show();
                    }
                 }
                  break;

            case R.id.img_finalizar_chamado:

                 if(chamadosModel.getIdStatusChamado() == 4){

                    Snackbar.make(view, "Chamado Finalizado"   ,
                            Snackbar.LENGTH_LONG)
                            .setAction("No action", null).show();

                }

                break;
        }

    }

    @NonNull
    @Override
    public View getView(int position,
                        View dataSet,
                        @NonNull ViewGroup parent) {

        ChamadosModel chamadosModel = getItem(position);

        FinalizadosListAdapter.ViewHolder linha;


        if (dataSet == null) {

            linha = new FinalizadosListAdapter.ViewHolder();

            LayoutInflater layoutTodosChamadoslList = LayoutInflater.from(getContext());

            dataSet = layoutTodosChamadoslList.inflate(R.layout.list_view_finalizados_fragment,
                    parent,
                    false);

            linha.txt_tipo_chamado = dataSet.findViewById(R.id.txt_tipo_chamado);
            linha.txt_nome_cliente = dataSet.findViewById(R.id.txt_nome_cliente);
            linha.txt_endereco_cliente = dataSet.findViewById(R.id.txt_end_cliente);
            linha.txt_data_marcada = dataSet.findViewById(R.id.txt_data_marcada);
            linha.img_tipo_chamado = dataSet.findViewById(R.id.img_tipo_chamado);
            linha.img_finalizar_chamado = dataSet.findViewById(R.id.img_finalizar_chamado);

            dataSet.setTag(linha);


        } else {

            linha = (FinalizadosListAdapter.ViewHolder) dataSet.getTag();

        }

        linha.txt_tipo_chamado.setText(tipoChamado(chamadosModel.getTipoChamado()));

        if (chamadosModel.getIdStatusChamado() == 4){

            linha.img_finalizar_chamado.setVisibility(View.VISIBLE);
            linha.img_tipo_chamado.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_img_logo_chamado_finalizado));
            linha.img_finalizar_chamado.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_chamado_finalizado));

        }

        linha.txt_nome_cliente.setText(chamadosModel.getClientVO().getNome());
        linha.txt_endereco_cliente.setText(chamadosModel.getClientVO().getEnderecoModel().getRua());
        linha.txt_data_marcada.setText(String.valueOf(chamadosModel.getAgendamento()));

        linha.img_tipo_chamado.setOnClickListener(this);
        linha.img_tipo_chamado.setTag(position);
        linha.img_finalizar_chamado.setOnClickListener(this);
        linha.img_finalizar_chamado.setTag(position);

        return dataSet;
    }

    private void atualizarLista(ArrayList<ChamadosModel> novosDados) {
        this.dados.clear();
        this.dados.addAll(novosDados);
        notifyDataSetChanged();
    }

    private String tipoChamado(int tipoChamado){

        if(tipoChamado == 2){
            return "Manutenção";
        }else if(tipoChamado == 1){
            return "Instalações";
        }
        return null;
    }
}
