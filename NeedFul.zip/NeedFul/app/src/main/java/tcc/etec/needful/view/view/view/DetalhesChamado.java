package tcc.etec.needful.view.view.view;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import tcc.etec.needful.R;
import tcc.etec.needful.view.view.controller.ChamadosController;
import tcc.etec.needful.view.view.helper.Permissoes;
import tcc.etec.needful.view.view.model.ChamadosModel;
import tcc.etec.needful.view.view.util.AlterarAsynTask;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class DetalhesChamado extends AppCompatActivity {

    AlertDialog.Builder build;
    AlertDialog alert;
    ChamadosController controller;
    ChamadosModel chamados;
    Context context;
    private int idChamado;

    ImageButton ligarTelefone;
    ImageButton ligarCelular;
    TextView tipo_chamado;
    TextView nomeCliente;
    TextView enderecoCliente;
    TextView telefoneCliente;
    TextView celularCliente;
    TextView roteador;
    TextView cabo;
    TextView observacoes;
    TextView login;
    TextView senha;
    ImageView imgConfirmar;
    ImageView imgLocalizacao;

    private String[] permissoes = new String[]{
            Manifest.permission.ACCESS_FINE_LOCATION
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_chamado);

        //validar permissões
        Permissoes.validarPermissoes(permissoes, this, 1);

        context = getBaseContext();
        Intent intent = getIntent();
        this.idChamado = intent.getIntExtra("id_chamado", 0);
        int tipoChamado = intent.getIntExtra("id_tipo_chamado", 0);

        inicialiarComponentes();
        tipo_chamado.setText(tipoChamado(tipoChamado));
        pesquisarChamado(idChamado);
        exibirTelefone(chamados.getClientVO().getTelefone(), telefoneCliente, ligarTelefone);
        exibirCelular(chamados.getClientVO().getCelular(), celularCliente, ligarCelular);
        setarDados();

        final String enderecoCompleto = chamados.getClientVO().getEnderecoModel().getRua() + " " +
                chamados.getClientVO().getEnderecoModel().getBairro() + " " + chamados.getClientVO().getEnderecoModel().getNumero();

        imgConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    build = new AlertDialog.Builder(DetalhesChamado.this);
                    build.setTitle("ALERTA");
                    build.setMessage("Deseja CONFIRMAR este chamado?");
                    build.setCancelable(true);
                    build.setIcon(R.mipmap.ic_launcher);

                    build.setPositiveButton("SIM", new Dialog.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            chamados.setIdStatusChamado(2);
                            ChamadosController controller = new ChamadosController(context);
                            controller.alterar(chamados);
                            AlterarAsynTask alterar = new AlterarAsynTask(chamados, context);
                            alterar.execute();
                            pesquisarChamado(idChamado);
                            setarDados();
                            ativarDesativarBotaoConfirmar();
                            Toast.makeText(context, "Chamado confirmado com sucesso!", Toast.LENGTH_SHORT).show();
                        }
                    });
                    build.setNegativeButton("CANCELAR", new Dialog.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });

                    alert = build.create();
                    alert.show();
            }
        });

        imgLocalizacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Uri uri = Uri.parse("google.navigation:q=" + enderecoCompleto + "&mode=d");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, uri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

        getSupportActionBar().setTitle(tipoChamado(chamados.getTipoChamado()));

        ligarTelefone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fazerLigacaoTelefone();
            }
        });

        ligarCelular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fazerLigacaoCelular();
            }
        });

        ativarDesativarBotaoConfirmar();

    }

    private void pesquisarChamado(int idChamado) {
        chamados = new ChamadosModel();
        controller = new ChamadosController(context);
        chamados = controller.buscarPorid(idChamado);
    }

    private void ativarDesativarBotaoConfirmar() {
        if (chamados.getIdStatusChamado() == 2) {
            imgConfirmar.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_confirmar_desabilitado));
            imgConfirmar.setEnabled(false);
        } else if (chamados.getIdStatusChamado() == 4) {
            imgConfirmar.setEnabled(false);
            imgLocalizacao.setEnabled(false);
            imgLocalizacao.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_location_desabilitado));
            imgConfirmar.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_confirmar_desabilitado));
        } else {
            imgConfirmar.setEnabled(true);
            imgLocalizacao.setEnabled(true);
        }
    }

    private void setarDados() {
        nomeCliente.setText(chamados.getClientVO().getNome());
        enderecoCliente.setText(chamados.getClientVO().getEnderecoModel().getRua() + " " +
                chamados.getClientVO().getEnderecoModel().getNumero());
        roteador.setText(chamados.getClientVO().getRoteador());
        observacoes.setText(chamados.getDescricao());
        cabo.setText(chamados.getClientVO().getCabeamento());
        login.setText(chamados.getClientVO().getLogin());
        senha.setText(chamados.getClientVO().getSenha());
    }

    private void exibirCelular(String celular, TextView celularCliente, ImageButton ligarCelular) {
        if (celular == null || celular.equals("null")) {
            celularCliente.setText("");
            ligarCelular.setVisibility(View.INVISIBLE);
        } else {
            celularCliente.setText(celular);
        }
    }

    private void exibirTelefone(String telefone, TextView telefoneCliente, ImageButton ligarTelefone) {
        if (telefone == null || telefone.equals("null")) {
            telefoneCliente.setText("");
            ligarTelefone.setVisibility(View.INVISIBLE);
        } else {
            telefoneCliente.setText(telefone);
        }
    }

    private String tipoChamado(int tipoChamado) {

        if (tipoChamado == 1) {
            return "Instalação";
        } else if (tipoChamado == 2) {
            return "Manutenção";
        }
        return null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        for (int permissoesResultado : grantResults) {
            if (permissoesResultado == PackageManager.PERMISSION_DENIED) {
                alertaValidacaoPermissao();
            }
        }
    }

    private void alertaValidacaoPermissao() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Permissões Negadas");
        builder.setMessage("Para utilizar a rota é necessário aceitar as permissões");
        builder.setCancelable(false);
        builder.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();

    }
    private void fazerLigacaoTelefone(){
        Intent i = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", chamados.getClientVO().getTelefone(), null));
        startActivity(i);
    }

    private void fazerLigacaoCelular(){
        Intent i = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", chamados.getClientVO().getCelular(), null));
        startActivity(i);
    }

    private void inicialiarComponentes(){

        tipo_chamado = findViewById(R.id.txt_tipo_chamado);
        nomeCliente = findViewById(R.id.txt_nome_cliente);
        enderecoCliente = findViewById(R.id.txt_endereco_cliente);
        telefoneCliente = findViewById(R.id.txt_telefone_cliente);
        celularCliente = findViewById(R.id.txt_celular_cliente);
        roteador = findViewById(R.id.txt_roteador);
        observacoes = findViewById(R.id.txt_observacoes);
        cabo = findViewById(R.id.txt_cabeamento);
        login = findViewById(R.id.txt_login_cliente);
        senha = findViewById(R.id.txt_senha_usuario);
        imgConfirmar = findViewById(R.id.img_confirmar);
        imgLocalizacao = findViewById(R.id.img_localizacao);
        ligarTelefone = findViewById(R.id.btnLigarTelefone);
        ligarCelular = findViewById(R.id.btnligarCelular);
    }

}
