package tcc.etec.needful.view.view.api;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;
import java.util.concurrent.ExecutionException;

import tcc.etec.needful.view.view.model.ChamadosModel;

public class WebServiceChamado {

    private Gson gson = new Gson();
    private Type chamadoType = new TypeToken<ChamadosModel>() {
    }.getType();
    private Type listChamadoType = new TypeToken<List<ChamadosModel>>() {
    }.getType();
    private Type listStringType = new TypeToken<List<String>>() {
    }.getType();
    private WebService webService;
    // URL[
    private final static String IP = "18.228.43.192";

    private String listagemFiltro = "http://" + IP + ":8080/WSNeedful/webresources/chamados/listagemfiltropost/";
    private String pesquisaTipoDeChamado = "http://" + IP
            + ":8080/WSNeedful/webresources/chamados/pesquisaTipoDeChamado/";
    private String FECHARCHAMADO = "http://" + IP + ":8080/WSNeedful/webresources/chamados/fecharChamadomanutencao/";
    private String atualizarInstalacao = "http://" + IP
            + ":8080/WSNeedful/webresources/chamados/alteraChamadoinstalacao/";
    private String atualizarmanutencao = "http://" + IP
            + ":8080/WSNeedful/webresources/chamados/alteraChamadomanutencao/";
    private String CARREGARTELADEINSTALACAO = "http://" + IP
            + ":8080/WSNeedful/webresources/chamados/carregarTelaEdicaoInstalacao/";
    private String carregarteladeManuntecao = "http://" + IP
            + ":8080/WSNeedful/webresources/chamados/carregarTelaEdicaoManutencao/";

    // Metodos do Web Services
    final String POST = "POST";
    final String PUT = "PUT";
    final String GET = "GET";
    final String DELETE = "DELETE";

    public List<ChamadosModel> listagempost(ChamadosModel chamados) throws IOException, ExecutionException, InterruptedException {
        String json = gson.toJson(chamados);
        String retornoJson = new WebService(listagemFiltro,json,POST).execute().get();
        //STRING EM FORMATO DE JSON
        //TENTAR CONVERTER O retornoJson COM O RETROFIT.
        return gson.fromJson(retornoJson, listChamadoType);
    }

   /* public boolean fecharChamado(ChamadosModel chamados) throws IOException {
        String json = gson.toJson(chamados);

        return Boolean.parseBoolean(httpClient.sendPUT(FECHARCHAMADO, json, PUT));
    }

    public ChamadosModel carregarTelaEdicaoInstalacao(ChamadosModel chamados) throws IOException {
        String json = gson.toJson(chamados);

        return gson.fromJson(httpClient.sendPOST(CARREGARTELADEINSTALACAO, json, POST), chamadoType);
    }

    public ChamadosModel carregarteladeManuntecao(ChamadosModel chamados) throws IOException {
        String json = gson.toJson(chamados);

        return gson.fromJson(httpClient.sendPOST(carregarteladeManuntecao, json, POST), chamadoType);
    }

    public boolean atualizarInstalacao(ChamadosModel chamados) throws IOException {
        String json = gson.toJson(chamados);
        System.out.println(json);
        return Boolean.parseBoolean(httpClient.sendPUT(atualizarInstalacao, json, PUT));
    }

    public boolean atualizarmanutencao(ChamadosModel chamados) throws IOException {
        String json = gson.toJson(chamados);
        System.out.println(json);
        String re = httpClient.sendPUT(atualizarmanutencao, json, PUT);
        return Boolean.parseBoolean(httpClient.sendPUT(atualizarmanutencao, json, PUT));
    }*/

}
